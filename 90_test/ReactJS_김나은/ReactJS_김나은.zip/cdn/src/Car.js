function Car() {
    return <h2>저요!</h2>;
}

// 내보내기
// export default 컴포넌트명;
// export default Car;